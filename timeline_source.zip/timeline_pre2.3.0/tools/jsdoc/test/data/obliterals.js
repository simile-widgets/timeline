// nested object literals

/** A document. */
var Document = {
	Author: {
		/** The author's email address. */
		Email: {
		},
		Name: {
			/** Lastname. */
			surname: {
			}
		}
	},
	PubDate: {
	
	}
}