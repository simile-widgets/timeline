﻿function _peek(record) {
}

/*
[
    {
        symbols: [
            {
                doc: { tags: [] },
                returns: [],
                type: "",
                properties: [],
                isa: "FUNCTION",
                desc: "undocumented",
                alias: "_peek",
                memberof: "",
                params: [
                    {
                        title: "param",
                        desc: "",
                        type: "",
                        name: "record",
                        isOptional: false
                    }
                ],
                methods: [],
                name: "_peek"
            }
        ],
        overview: {
            doc: { tags: [] },
            returns: [],
            type: "",
            properties: [],
            isa: "FILE",
            desc: "No overview provided.",
            alias: "examples/data/underscored_function1.js",
            memberof: "",
            params: [],
            methods: [],
            name: "examples/data/underscored_function1.js"
        }
    }
]
*/